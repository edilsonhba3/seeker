import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public productos: any[];
  public encabezados: String[];
  public keys: String[];

  constructor() { }

  ngOnInit() {
    this.keys = ["id", "employee_name", "employee_salary", "employee_age"];
    this.encabezados = ["Id", "Nombre", "Salario", "Edad", "Acciones"];
    this.productos = [
      {
        "id": "14533",
        "employee_name": "ntrddaecky",
        "employee_salary": "50000",
        "employee_age": "24",
        "profile_image": ""
      },
      {
        "id": "14535",
        "employee_name": "Anshu",
        "employee_salary": "12000",
        "employee_age": "22",
        "profile_image": ""
      },
      {
        "id": "14536",
        "employee_name": "tsesas111",
        "employee_salary": "123",
        "employee_age": "23",
        "profile_image": ""
      },
      {
        "id": "14537",
        "employee_name": "ntrdfddaecky",
        "employee_salary": "50000",
        "employee_age": "24",
        "profile_image": ""
      },
      {
        "id": "14541",
        "employee_name": "amar nam",
        "employee_salary": "2344",
        "employee_age": "12",
        "profile_image": ""
      }
    ];
  }

}
